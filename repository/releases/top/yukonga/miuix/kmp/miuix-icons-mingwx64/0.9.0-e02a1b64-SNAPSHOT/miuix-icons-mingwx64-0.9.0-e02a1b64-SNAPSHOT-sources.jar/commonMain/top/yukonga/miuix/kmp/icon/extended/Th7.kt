// Copyright 2025, compose-miuix-ui contributors
// SPDX-License-Identifier: Apache-2.0

package top.yukonga.miuix.kmp.icon.extended

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathNode
import androidx.compose.ui.graphics.vector.group
import androidx.compose.ui.unit.dp
import top.yukonga.miuix.kmp.icon.MiuixIcons

val MiuixIcons.Th7: ImageVector
    get() = MiuixIcons.Regular.Th7

val MiuixIcons.Light.Th7: ImageVector
    get() {
        if (_th7Light != null) return _th7Light!!
        _th7Light = ImageVector.Builder(
            name = "Th7.Light",
            defaultWidth = 24.0f.dp,
            defaultHeight = 24.0f.dp,
            viewportWidth = 1165.2f,
            viewportHeight = 1165.2f,
        ).apply {
            group(scaleX = 1.0f, scaleY = -1.0f, translationX = -81.89999999999998f, translationY = 957.6f) {
                addPath(
                    pathData = listOf(
                        PathNode.MoveTo(1066.0f, -57.0f),
                        PathNode.QuadTo(1110.0f, -36.0f, 1133.0f, 9.0f),
                        PathNode.QuadTo(1145.0f, 32.0f, 1147.5f, 65.0f),
                        PathNode.QuadTo(1150.0f, 98.0f, 1150.0f, 178.0f),
                        PathNode.VerticalTo(572.0f),
                        PathNode.QuadTo(1150.0f, 653.0f, 1147.5f, 686.0f),
                        PathNode.QuadTo(1145.0f, 719.0f, 1133.0f, 742.0f),
                        PathNode.QuadTo(1111.0f, 785.0f, 1066.0f, 808.0f),
                        PathNode.QuadTo(1044.0f, 820.0f, 1011.0f, 822.5f),
                        PathNode.QuadTo(978.0f, 825.0f, 897.0f, 825.0f),
                        PathNode.HorizontalTo(432.0f),
                        PathNode.QuadTo(351.0f, 825.0f, 318.0f, 822.5f),
                        PathNode.QuadTo(285.0f, 820.0f, 263.0f, 808.0f),
                        PathNode.QuadTo(219.0f, 786.0f, 196.0f, 742.0f),
                        PathNode.QuadTo(184.0f, 719.0f, 181.5f, 686.0f),
                        PathNode.QuadTo(179.0f, 653.0f, 179.0f, 572.0f),
                        PathNode.VerticalTo(178.0f),
                        PathNode.QuadTo(179.0f, 98.0f, 181.5f, 65.0f),
                        PathNode.QuadTo(184.0f, 32.0f, 196.0f, 9.0f),
                        PathNode.QuadTo(220.0f, -37.0f, 263.0f, -57.0f),
                        PathNode.QuadTo(285.0f, -69.0f, 318.0f, -72.0f),
                        PathNode.QuadTo(351.0f, -75.0f, 432.0f, -75.0f),
                        PathNode.HorizontalTo(897.0f),
                        PathNode.QuadTo(978.0f, -75.0f, 1011.0f, -72.0f),
                        PathNode.QuadTo(1044.0f, -69.0f, 1066.0f, -57.0f),
                        PathNode.Close,
                        PathNode.MoveTo(296.0f, 3.0f),
                        PathNode.QuadTo(269.0f, 18.0f, 257.0f, 43.0f),
                        PathNode.QuadTo(251.0f, 56.0f, 249.5f, 73.5f),
                        PathNode.QuadTo(248.0f, 91.0f, 248.0f, 129.0f),
                        PathNode.VerticalTo(491.0f),
                        PathNode.QuadTo(248.0f, 529.0f, 249.5f, 546.5f),
                        PathNode.QuadTo(251.0f, 564.0f, 257.0f, 577.0f),
                        PathNode.QuadTo(270.0f, 603.0f, 296.0f, 616.0f),
                        PathNode.QuadTo(309.0f, 622.0f, 326.5f, 623.5f),
                        PathNode.QuadTo(344.0f, 625.0f, 382.0f, 625.0f),
                        PathNode.HorizontalTo(946.0f),
                        PathNode.QuadTo(984.0f, 625.0f, 1001.5f, 623.5f),
                        PathNode.QuadTo(1019.0f, 622.0f, 1032.0f, 616.0f),
                        PathNode.QuadTo(1057.0f, 604.0f, 1072.0f, 577.0f),
                        PathNode.QuadTo(1078.0f, 565.0f, 1079.5f, 547.0f),
                        PathNode.QuadTo(1081.0f, 529.0f, 1081.0f, 491.0f),
                        PathNode.VerticalTo(129.0f),
                        PathNode.QuadTo(1081.0f, 91.0f, 1079.5f, 73.5f),
                        PathNode.QuadTo(1078.0f, 56.0f, 1072.0f, 43.0f),
                        PathNode.QuadTo(1058.0f, 17.0f, 1032.0f, 3.0f),
                        PathNode.QuadTo(1019.0f, -3.0f, 1001.5f, -4.5f),
                        PathNode.QuadTo(984.0f, -6.0f, 946.0f, -6.0f),
                        PathNode.HorizontalTo(382.0f),
                        PathNode.QuadTo(344.0f, -6.0f, 326.0f, -4.5f),
                        PathNode.QuadTo(308.0f, -3.0f, 296.0f, 3.0f),
                        PathNode.Close,
                        PathNode.MoveTo(609.0f, 147.0f),
                        PathNode.HorizontalTo(641.0f),
                        PathNode.QuadTo(649.0f, 147.0f, 652.0f, 154.0f),
                        PathNode.LineTo(776.0f, 439.0f),
                        PathNode.QuadTo(779.0f, 445.0f, 779.0f, 452.0f),
                        PathNode.VerticalTo(467.0f),
                        PathNode.QuadTo(779.0f, 471.0f, 776.0f, 474.0f),
                        PathNode.QuadTo(773.0f, 477.0f, 769.0f, 477.0f),
                        PathNode.HorizontalTo(581.0f),
                        PathNode.QuadTo(577.0f, 477.0f, 574.0f, 474.5f),
                        PathNode.QuadTo(571.0f, 472.0f, 571.0f, 467.0f),
                        PathNode.VerticalTo(441.0f),
                        PathNode.QuadTo(571.0f, 437.0f, 574.0f, 434.0f),
                        PathNode.QuadTo(577.0f, 431.0f, 581.0f, 431.0f),
                        PathNode.HorizontalTo(721.0f),
                        PathNode.LineTo(601.0f, 159.0f),
                        PathNode.QuadTo(599.0f, 154.0f, 601.0f, 150.5f),
                        PathNode.QuadTo(603.0f, 147.0f, 609.0f, 147.0f),
                        PathNode.Close,
                    ),
                    fill = SolidColor(Color.Black),
                    fillAlpha = 1f,
                    pathFillType = PathFillType.NonZero,
                )
            }
        }.build()
        return _th7Light!!
    }

private var _th7Light: ImageVector? = null

val MiuixIcons.Regular.Th7: ImageVector
    get() {
        if (_th7Regular != null) return _th7Regular!!
        _th7Regular = ImageVector.Builder(
            name = "Th7.Regular",
            defaultWidth = 24.0f.dp,
            defaultHeight = 24.0f.dp,
            viewportWidth = 1196.3999999999999f,
            viewportHeight = 1196.3999999999999f,
        ).apply {
            group(scaleX = 1.0f, scaleY = -1.0f, translationX = -66.30000000000007f, translationY = 973.1999999999999f) {
                addPath(
                    pathData = listOf(
                        PathNode.MoveTo(1072.0f, -69.0f),
                        PathNode.QuadTo(1120.0f, -46.0f, 1145.0f, 3.0f),
                        PathNode.QuadTo(1157.0f, 28.0f, 1160.0f, 62.5f),
                        PathNode.QuadTo(1163.0f, 97.0f, 1163.0f, 178.0f),
                        PathNode.VerticalTo(572.0f),
                        PathNode.QuadTo(1163.0f, 654.0f, 1160.0f, 688.5f),
                        PathNode.QuadTo(1157.0f, 723.0f, 1145.0f, 748.0f),
                        PathNode.QuadTo(1121.0f, 795.0f, 1072.0f, 820.0f),
                        PathNode.QuadTo(1048.0f, 832.0f, 1013.5f, 835.0f),
                        PathNode.QuadTo(979.0f, 838.0f, 897.0f, 838.0f),
                        PathNode.HorizontalTo(432.0f),
                        PathNode.QuadTo(351.0f, 838.0f, 316.0f, 835.0f),
                        PathNode.QuadTo(281.0f, 832.0f, 257.0f, 820.0f),
                        PathNode.QuadTo(209.0f, 796.0f, 184.0f, 748.0f),
                        PathNode.QuadTo(172.0f, 723.0f, 169.0f, 688.5f),
                        PathNode.QuadTo(166.0f, 654.0f, 166.0f, 572.0f),
                        PathNode.VerticalTo(178.0f),
                        PathNode.QuadTo(166.0f, 97.0f, 169.0f, 62.5f),
                        PathNode.QuadTo(172.0f, 28.0f, 184.0f, 3.0f),
                        PathNode.QuadTo(210.0f, -47.0f, 257.0f, -69.0f),
                        PathNode.QuadTo(281.0f, -82.0f, 316.0f, -85.0f),
                        PathNode.QuadTo(351.0f, -88.0f, 432.0f, -88.0f),
                        PathNode.HorizontalTo(897.0f),
                        PathNode.QuadTo(979.0f, -88.0f, 1013.5f, -85.0f),
                        PathNode.QuadTo(1048.0f, -82.0f, 1072.0f, -69.0f),
                        PathNode.Close,
                        PathNode.MoveTo(302.0f, 15.0f),
                        PathNode.QuadTo(279.0f, 28.0f, 269.0f, 49.0f),
                        PathNode.QuadTo(263.0f, 60.0f, 262.0f, 76.0f),
                        PathNode.QuadTo(261.0f, 92.0f, 261.0f, 129.0f),
                        PathNode.VerticalTo(491.0f),
                        PathNode.QuadTo(261.0f, 528.0f, 262.5f, 544.0f),
                        PathNode.QuadTo(264.0f, 560.0f, 269.0f, 571.0f),
                        PathNode.QuadTo(280.0f, 593.0f, 302.0f, 604.0f),
                        PathNode.QuadTo(313.0f, 609.0f, 329.0f, 610.5f),
                        PathNode.QuadTo(345.0f, 612.0f, 382.0f, 612.0f),
                        PathNode.HorizontalTo(946.0f),
                        PathNode.QuadTo(984.0f, 612.0f, 999.5f, 611.0f),
                        PathNode.QuadTo(1015.0f, 610.0f, 1026.0f, 604.0f),
                        PathNode.QuadTo(1047.0f, 594.0f, 1060.0f, 571.0f),
                        PathNode.QuadTo(1065.0f, 560.0f, 1066.5f, 544.0f),
                        PathNode.QuadTo(1068.0f, 528.0f, 1068.0f, 491.0f),
                        PathNode.VerticalTo(129.0f),
                        PathNode.QuadTo(1068.0f, 92.0f, 1067.0f, 76.0f),
                        PathNode.QuadTo(1066.0f, 60.0f, 1060.0f, 49.0f),
                        PathNode.QuadTo(1048.0f, 27.0f, 1026.0f, 15.0f),
                        PathNode.QuadTo(1015.0f, 9.0f, 999.5f, 8.0f),
                        PathNode.QuadTo(984.0f, 7.0f, 946.0f, 7.0f),
                        PathNode.HorizontalTo(382.0f),
                        PathNode.QuadTo(345.0f, 7.0f, 329.0f, 8.5f),
                        PathNode.QuadTo(313.0f, 10.0f, 302.0f, 15.0f),
                        PathNode.Close,
                        PathNode.MoveTo(598.0f, 139.0f),
                        PathNode.HorizontalTo(647.0f),
                        PathNode.QuadTo(659.0f, 139.0f, 664.0f, 150.0f),
                        PathNode.LineTo(788.0f, 423.0f),
                        PathNode.QuadTo(792.0f, 432.0f, 792.0f, 442.0f),
                        PathNode.VerticalTo(464.0f),
                        PathNode.QuadTo(792.0f, 471.0f, 788.0f, 475.0f),
                        PathNode.QuadTo(784.0f, 479.0f, 777.0f, 479.0f),
                        PathNode.HorizontalTo(575.0f),
                        PathNode.QuadTo(568.0f, 479.0f, 564.0f, 475.0f),
                        PathNode.QuadTo(560.0f, 471.0f, 560.0f, 464.0f),
                        PathNode.LineTo(561.0f, 424.0f),
                        PathNode.QuadTo(561.0f, 417.0f, 565.0f, 413.0f),
                        PathNode.QuadTo(569.0f, 409.0f, 576.0f, 409.0f),
                        PathNode.HorizontalTo(704.0f),
                        PathNode.LineTo(587.0f, 157.0f),
                        PathNode.QuadTo(583.0f, 149.0f, 586.5f, 144.0f),
                        PathNode.QuadTo(590.0f, 139.0f, 598.0f, 139.0f),
                        PathNode.Close,
                    ),
                    fill = SolidColor(Color.Black),
                    fillAlpha = 1f,
                    pathFillType = PathFillType.NonZero,
                )
            }
        }.build()
        return _th7Regular!!
    }

private var _th7Regular: ImageVector? = null

val MiuixIcons.Heavy.Th7: ImageVector
    get() {
        if (_th7Heavy != null) return _th7Heavy!!
        _th7Heavy = ImageVector.Builder(
            name = "Th7.Heavy",
            defaultWidth = 24.0f.dp,
            defaultHeight = 24.0f.dp,
            viewportWidth = 1230.0f,
            viewportHeight = 1230.0f,
        ).apply {
            group(scaleX = 1.0f, scaleY = -1.0f, translationX = -49.5f, translationY = 990.0f) {
                addPath(
                    pathData = listOf(
                        PathNode.MoveTo(1078.0f, -81.0f),
                        PathNode.QuadTo(1130.0f, -56.0f, 1157.0f, -3.0f),
                        PathNode.QuadTo(1171.0f, 24.0f, 1174.0f, 60.0f),
                        PathNode.QuadTo(1177.0f, 96.0f, 1177.0f, 178.0f),
                        PathNode.VerticalTo(572.0f),
                        PathNode.QuadTo(1177.0f, 655.0f, 1174.0f, 691.0f),
                        PathNode.QuadTo(1171.0f, 727.0f, 1157.0f, 754.0f),
                        PathNode.QuadTo(1131.0f, 805.0f, 1078.0f, 832.0f),
                        PathNode.QuadTo(1052.0f, 846.0f, 1015.5f, 849.0f),
                        PathNode.QuadTo(979.0f, 852.0f, 897.0f, 852.0f),
                        PathNode.HorizontalTo(432.0f),
                        PathNode.QuadTo(350.0f, 852.0f, 313.5f, 849.0f),
                        PathNode.QuadTo(277.0f, 846.0f, 251.0f, 832.0f),
                        PathNode.QuadTo(198.0f, 806.0f, 172.0f, 754.0f),
                        PathNode.QuadTo(158.0f, 727.0f, 155.0f, 691.0f),
                        PathNode.QuadTo(152.0f, 655.0f, 152.0f, 572.0f),
                        PathNode.VerticalTo(178.0f),
                        PathNode.QuadTo(152.0f, 96.0f, 155.0f, 60.0f),
                        PathNode.QuadTo(158.0f, 24.0f, 172.0f, -3.0f),
                        PathNode.QuadTo(200.0f, -58.0f, 251.0f, -81.0f),
                        PathNode.QuadTo(277.0f, -95.0f, 313.5f, -98.5f),
                        PathNode.QuadTo(350.0f, -102.0f, 432.0f, -102.0f),
                        PathNode.HorizontalTo(897.0f),
                        PathNode.QuadTo(979.0f, -102.0f, 1015.5f, -98.5f),
                        PathNode.QuadTo(1052.0f, -95.0f, 1078.0f, -81.0f),
                        PathNode.Close,
                        PathNode.MoveTo(308.0f, 27.0f),
                        PathNode.QuadTo(290.0f, 38.0f, 281.0f, 55.0f),
                        PathNode.QuadTo(277.0f, 64.0f, 276.0f, 82.5f),
                        PathNode.QuadTo(275.0f, 101.0f, 275.0f, 129.0f),
                        PathNode.VerticalTo(491.0f),
                        PathNode.QuadTo(275.0f, 518.0f, 276.0f, 537.0f),
                        PathNode.QuadTo(277.0f, 556.0f, 281.0f, 565.0f),
                        PathNode.QuadTo(291.0f, 582.0f, 308.0f, 592.0f),
                        PathNode.QuadTo(317.0f, 596.0f, 336.0f, 597.0f),
                        PathNode.QuadTo(355.0f, 598.0f, 382.0f, 598.0f),
                        PathNode.HorizontalTo(946.0f),
                        PathNode.QuadTo(974.0f, 598.0f, 992.5f, 597.0f),
                        PathNode.QuadTo(1011.0f, 596.0f, 1020.0f, 592.0f),
                        PathNode.QuadTo(1037.0f, 583.0f, 1048.0f, 565.0f),
                        PathNode.QuadTo(1052.0f, 556.0f, 1053.0f, 537.0f),
                        PathNode.QuadTo(1054.0f, 518.0f, 1054.0f, 491.0f),
                        PathNode.VerticalTo(129.0f),
                        PathNode.QuadTo(1054.0f, 101.0f, 1053.0f, 82.5f),
                        PathNode.QuadTo(1052.0f, 64.0f, 1048.0f, 55.0f),
                        PathNode.QuadTo(1038.0f, 37.0f, 1020.0f, 27.0f),
                        PathNode.QuadTo(1011.0f, 23.0f, 992.5f, 22.0f),
                        PathNode.QuadTo(974.0f, 21.0f, 946.0f, 21.0f),
                        PathNode.HorizontalTo(382.0f),
                        PathNode.QuadTo(355.0f, 21.0f, 336.0f, 22.0f),
                        PathNode.QuadTo(317.0f, 23.0f, 308.0f, 27.0f),
                        PathNode.Close,
                        PathNode.MoveTo(606.0f, 137.0f),
                        PathNode.HorizontalTo(644.0f),
                        PathNode.QuadTo(664.0f, 137.0f, 673.0f, 155.0f),
                        PathNode.LineTo(793.0f, 419.0f),
                        PathNode.QuadTo(799.0f, 430.0f, 799.0f, 448.0f),
                        PathNode.VerticalTo(460.0f),
                        PathNode.QuadTo(799.0f, 472.0f, 792.0f, 479.0f),
                        PathNode.QuadTo(785.0f, 486.0f, 774.0f, 486.0f),
                        PathNode.HorizontalTo(582.0f),
                        PathNode.QuadTo(570.0f, 486.0f, 563.0f, 479.0f),
                        PathNode.QuadTo(556.0f, 472.0f, 556.0f, 460.0f),
                        PathNode.LineTo(557.0f, 430.0f),
                        PathNode.QuadTo(557.0f, 419.0f, 564.0f, 411.5f),
                        PathNode.QuadTo(571.0f, 404.0f, 582.0f, 404.0f),
                        PathNode.HorizontalTo(697.0f),
                        PathNode.LineTo(587.0f, 168.0f),
                        PathNode.QuadTo(580.0f, 155.0f, 586.0f, 146.0f),
                        PathNode.QuadTo(592.0f, 137.0f, 606.0f, 137.0f),
                        PathNode.Close,
                    ),
                    fill = SolidColor(Color.Black),
                    fillAlpha = 1f,
                    pathFillType = PathFillType.NonZero,
                )
            }
        }.build()
        return _th7Heavy!!
    }

private var _th7Heavy: ImageVector? = null
