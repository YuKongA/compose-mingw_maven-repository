package androidx.compose.material3.windowsizeclass

@MustBeDocumented
@Target(AnnotationTarget.FUNCTION)
actual annotation class TestOnly
