/*
 * Copyright 2020-2024 JetBrains s.r.o. and respective authors and developers.
 * Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE.txt file.
 */
package org.jetbrains.compose.resources.vector.xmldom

/**
 * Pure Kotlin XML parser for mingwX64.
 * Parses XML into a DOM tree (Element/Node/NodeList).
 * Supports namespaces, attributes, text content, and nested elements.
 */
internal fun parse(xml: String): Element {
    val parser = SimpleXmlParser(xml)
    return parser.parse()
}

private class ElementImpl(
    override val localName: String,
    override val nodeName: String,
    override val namespaceURI: String,
    val prefixMap: Map<String, String>,
    val attrs: Map<String, String>
) : Element {

    override var textContent: String? = null

    val children = mutableListOf<Node>()

    override val childNodes: NodeList
        get() = object : NodeList {
            override fun item(i: Int): Node = children[i]
            override val length: Int get() = children.size
        }

    override fun getAttributeNS(nameSpaceURI: String, localName: String): String {
        val prefix = prefixMap[nameSpaceURI]
        val attrKey = if (prefix == null) localName else "$prefix:$localName"
        return getAttribute(attrKey)
    }

    override fun getAttribute(name: String): String = attrs[name] ?: ""

    override fun lookupPrefix(namespaceURI: String): String = prefixMap[namespaceURI] ?: ""
}

private class SimpleXmlParser(private val xml: String) {
    private var pos = 0

    fun parse(): Element {
        // Skip XML declaration and comments
        skipProlog()
        return parseElement() ?: throw MalformedXMLException("No root element found")
    }

    private fun skipProlog() {
        skipWhitespace()
        while (pos < xml.length) {
            if (xml.startsWith("<?", pos)) {
                pos = xml.indexOf("?>", pos)
                if (pos < 0) throw MalformedXMLException("Unterminated processing instruction")
                pos += 2
                skipWhitespace()
            } else if (xml.startsWith("<!--", pos)) {
                pos = xml.indexOf("-->", pos)
                if (pos < 0) throw MalformedXMLException("Unterminated comment")
                pos += 3
                skipWhitespace()
            } else if (xml.startsWith("<!", pos)) {
                pos = xml.indexOf(">", pos)
                if (pos < 0) throw MalformedXMLException("Unterminated declaration")
                pos += 1
                skipWhitespace()
            } else {
                break
            }
        }
    }

    private fun parseElement(): ElementImpl? {
        skipWhitespace()
        if (pos >= xml.length || xml[pos] != '<') return null
        if (xml.startsWith("</", pos)) return null

        pos++ // skip '<'
        val tagName = readName()
        val attributes = mutableMapOf<String, String>()
        val prefixMapInverted = mutableMapOf<String, String>()

        // Parse attributes
        while (pos < xml.length) {
            skipWhitespace()
            if (xml[pos] == '/' || xml[pos] == '>') break
            val attrName = readName()
            skipWhitespace()
            expect('=')
            skipWhitespace()
            val attrValue = readQuotedString()
            attributes[attrName] = decodeXmlEntities(attrValue)

            // Track namespace prefixes
            if (attrName.startsWith("xmlns:")) {
                prefixMapInverted[attrName.substringAfter("xmlns:")] = attrValue
            }
        }

        val prefixMap = prefixMapInverted.entries.associateBy({ it.value }, { it.key })

        // Determine namespace
        val (localName, nsUri) = resolveNamespace(tagName, prefixMapInverted)

        val element = ElementImpl(localName, tagName, nsUri, prefixMap, attributes)

        if (xml[pos] == '/') {
            pos += 2 // skip '/>'
            return element
        }

        pos++ // skip '>'

        // Parse children and text content
        val textBuilder = StringBuilder()
        while (pos < xml.length) {
            if (xml.startsWith("</", pos)) {
                // Closing tag
                pos += 2
                val closingName = readName()
                skipWhitespace()
                expect('>')
                if (textBuilder.isNotEmpty()) {
                    element.textContent = textBuilder.toString()
                }
                return element
            } else if (xml.startsWith("<!--", pos)) {
                pos = xml.indexOf("-->", pos)
                if (pos < 0) throw MalformedXMLException("Unterminated comment")
                pos += 3
            } else if (xml[pos] == '<') {
                val child = parseElement()
                if (child != null) {
                    element.children.add(child)
                }
            } else {
                textBuilder.append(xml[pos])
                pos++
            }
        }

        return element
    }

    private fun resolveNamespace(tagName: String, prefixes: Map<String, String>): Pair<String, String> {
        val colonIndex = tagName.indexOf(':')
        return if (colonIndex >= 0) {
            val prefix = tagName.substring(0, colonIndex)
            val local = tagName.substring(colonIndex + 1)
            local to (prefixes[prefix] ?: "")
        } else {
            tagName to ""
        }
    }

    private fun readName(): String {
        val start = pos
        while (pos < xml.length && xml[pos] != ' ' && xml[pos] != '\t' && xml[pos] != '\n' &&
            xml[pos] != '\r' && xml[pos] != '=' && xml[pos] != '>' && xml[pos] != '/') {
            pos++
        }
        return xml.substring(start, pos)
    }

    private fun readQuotedString(): String {
        val quote = xml[pos]
        if (quote != '"' && quote != '\'') throw MalformedXMLException("Expected quote at position $pos")
        pos++
        val start = pos
        while (pos < xml.length && xml[pos] != quote) pos++
        val value = xml.substring(start, pos)
        pos++ // skip closing quote
        return value
    }

    private fun expect(c: Char) {
        if (pos >= xml.length || xml[pos] != c) {
            throw MalformedXMLException("Expected '$c' at position $pos")
        }
        pos++
    }

    private fun skipWhitespace() {
        while (pos < xml.length && xml[pos].isWhitespace()) pos++
    }

    private fun decodeXmlEntities(s: String): String {
        return s.replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
    }
}
