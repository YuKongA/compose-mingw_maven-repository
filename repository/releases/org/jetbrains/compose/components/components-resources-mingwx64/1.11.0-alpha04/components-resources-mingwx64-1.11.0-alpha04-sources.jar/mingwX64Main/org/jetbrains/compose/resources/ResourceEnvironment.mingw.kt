package org.jetbrains.compose.resources

import kotlinx.cinterop.COpaquePointerVar
import kotlinx.cinterop.UIntVar
import kotlinx.cinterop.addressOf
import kotlinx.cinterop.alloc
import kotlinx.cinterop.allocArray
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.reinterpret
import kotlinx.cinterop.toKString
import kotlinx.cinterop.usePinned
import kotlinx.cinterop.value
import platform.windows.GetDC
import platform.windows.GetDeviceCaps
import platform.windows.GetUserDefaultLocaleName
import platform.windows.HKEY_CURRENT_USER
import platform.windows.KEY_READ
import platform.windows.LOCALE_NAME_MAX_LENGTH
import platform.windows.LOGPIXELSX
import platform.windows.RegCloseKey
import platform.windows.RegOpenKeyExW
import platform.windows.RegQueryValueExW
import platform.windows.ReleaseDC
import platform.windows.WCHARVar

internal actual fun getSystemEnvironment(): ResourceEnvironment {
    val locale = getWindowsLocale()
    val parts = locale.split("-")
    val language = parts.getOrElse(0) { "en" }
    val region = parts.getOrElse(1) { "" }

    val isDark = isWindowsDarkTheme()

    val hdc = GetDC(null)
    val dpi = GetDeviceCaps(hdc, LOGPIXELSX)
    ReleaseDC(null, hdc)

    return ResourceEnvironment(
        language = LanguageQualifier(language),
        region = RegionQualifier(region),
        theme = ThemeQualifier.selectByValue(isDark),
        density = DensityQualifier.selectByValue(dpi)
    )
}

private fun getWindowsLocale(): String {
    memScoped {
        val buffer = allocArray<WCHARVar>(LOCALE_NAME_MAX_LENGTH)
        GetUserDefaultLocaleName(buffer, LOCALE_NAME_MAX_LENGTH)
        return buffer.toKString()
    }
}

private fun isWindowsDarkTheme(): Boolean {
    memScoped {
        // HKEY is an opaque pointer
        val hkeyVar = alloc<COpaquePointerVar>()
        val openResult = RegOpenKeyExW(
            HKEY_CURRENT_USER,
            "Software\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize",
            0u,
            KEY_READ.toUInt(),
            hkeyVar.ptr.reinterpret()
        )
        if (openResult != 0) return false

        val hkey = hkeyVar.value ?: return false

        // Query AppsUseLightTheme (DWORD: 0=dark, 1=light)
        val data = ByteArray(4)
        val dataSize = alloc<UIntVar>()
        dataSize.value = 4u

        val queryResult = data.usePinned { pinned ->
            RegQueryValueExW(
                hkey.reinterpret(),
                "AppsUseLightTheme",
                null,
                null,
                pinned.addressOf(0).reinterpret(),
                dataSize.ptr.reinterpret()
            )
        }
        RegCloseKey(hkey.reinterpret())

        if (queryResult != 0) return false
        return data[0].toInt() == 0
    }
}
