package org.jetbrains.compose.resources

import kotlinx.cinterop.addressOf
import kotlinx.cinterop.allocArray
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.toKString
import kotlinx.cinterop.usePinned
import platform.posix.SEEK_END
import platform.posix.SEEK_SET
import platform.posix.fclose
import platform.posix.fopen
import platform.posix.fread
import platform.posix.fseek
import platform.posix.ftell
import platform.windows.GetModuleFileNameW
import platform.windows.MAX_PATH
import platform.windows.WCHARVar

@ExperimentalResourceApi
internal actual fun getPlatformResourceReader(): ResourceReader = MingwResourceReader

@ExperimentalResourceApi
internal object MingwResourceReader : ResourceReader {
    override suspend fun read(path: String): ByteArray {
        val fullPath = getPathOnDisk(path)
        val file = fopen(fullPath, "rb") ?: throw MissingResourceException(path)
        try {
            fseek(file, 0, SEEK_END)
            val size = ftell(file)
            fseek(file, 0, SEEK_SET)
            val bytes = ByteArray(size.toInt())
            bytes.usePinned { pinned ->
                fread(pinned.addressOf(0), 1u, size.toULong(), file)
            }
            return bytes
        } finally {
            fclose(file)
        }
    }

    override suspend fun readPart(path: String, offset: Long, size: Long): ByteArray {
        val fullPath = getPathOnDisk(path)
        val file = fopen(fullPath, "rb") ?: throw MissingResourceException(path)
        try {
            fseek(file, offset.toInt(), SEEK_SET)
            val bytes = ByteArray(size.toInt())
            bytes.usePinned { pinned ->
                fread(pinned.addressOf(0), 1u, size.toULong(), file)
            }
            return bytes
        } finally {
            fclose(file)
        }
    }

    override fun getUri(path: String): String {
        return "file:///${getPathOnDisk(path).replace("\\", "/")}"
    }

    private fun getExeDirectory(): String {
        memScoped {
            val buffer = allocArray<WCHARVar>(MAX_PATH.toInt())
            GetModuleFileNameW(null, buffer, MAX_PATH.toUInt())
            val exePath = buffer.toKString()
            val lastSep = maxOf(exePath.lastIndexOf('\\'), exePath.lastIndexOf('/'))
            return if (lastSep >= 0) exePath.substring(0, lastSep) else exePath
        }
    }

    private fun getPathOnDisk(path: String): String {
        val pathFix = getPathWithoutPackage(path)
        val exeDir = getExeDirectory()
        return listOf(
            // Bundled resources next to executable
            "$exeDir/compose-resources/$path",
            "$exeDir/compose-resources/$pathFix",
            // Development-time: search source directories
            "src/mingwX64Main/composeResources/$pathFix",
            "src/commonMain/composeResources/$pathFix",
            "src/commonMain/composeResources/$path",
        ).firstOrNull { p -> fileExists(p) } ?: throw MissingResourceException(path)
    }

    private fun getPathWithoutPackage(path: String): String {
        if (!path.startsWith("composeResources/")) return path
        return path
            .substringAfter("composeResources/")
            .substringAfter("/")
    }

    private fun fileExists(path: String): Boolean {
        val f = fopen(path, "rb")
        if (f != null) {
            fclose(f)
            return true
        }
        return false
    }
}
