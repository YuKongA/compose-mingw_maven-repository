package org.jetbrains.skiko.redrawer

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.toLong
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import org.jetbrains.skia.ExternalSymbolName
import org.jetbrains.skia.impl.NativePointer
import org.jetbrains.skia.impl.Native
import org.jetbrains.skiko.FrameDispatcher
import org.jetbrains.skiko.RenderException
import org.jetbrains.skiko.SkiaLayer
import org.jetbrains.skiko.SkikoDispatchers
import org.jetbrains.skiko.context.MingwAngleContextHandler
import platform.windows.HWND

@OptIn(ExperimentalForeignApi::class)
internal class MingwAngleRedrawer(
    private val skiaLayer: SkiaLayer
) : Redrawer {

    private val hwnd: HWND = skiaLayer.component as? HWND
        ?: throw RenderException("SkiaLayer is not attached to an HWND")

    private val device: NativePointer = nAngleCreateDevice(hwnd.toLong()).also {
        if (it == Native.NullPointer) throw RenderException("Failed to create ANGLE device")
    }

    private val contextHandler = MingwAngleContextHandler(skiaLayer, device)
    private val coroutineScope = CoroutineScope(SkikoDispatchers.Main + Job())
    private val frameDispatcher = FrameDispatcher(coroutineScope) { draw() }

    private var isDisposed = false
    private var isRendering = false

    override fun dispose() {
        if (isDisposed) return
        isDisposed = true
        frameDispatcher.cancel()
        contextHandler.dispose()
        nAngleDispose(device)
    }

    override fun needRender(throttledToVsync: Boolean) {
        check(!isDisposed) { "MingwAngleRedrawer is disposed" }
        frameDispatcher.scheduleFrame()
    }

    override fun update(nanoTime: Long) {
        check(!isDisposed) { "MingwAngleRedrawer is disposed" }
        skiaLayer.update(nanoTime)
    }

    override fun renderImmediately() {
        check(!isDisposed) { "MingwAngleRedrawer is disposed" }
        if (isRendering) return
        isRendering = true
        skiaLayer.isRendering = true
        try {
            nAngleMakeCurrent(device)
            update()
            if (!isDisposed) {
                skiaLayer.inDrawScope {
                    contextHandler.draw()
                }
                nAngleSwapBuffers(device, 0)
            }
        } finally {
            skiaLayer.isRendering = false
            isRendering = false
        }
    }

    private fun draw() {
        if (isDisposed || isRendering) return
        isRendering = true
        skiaLayer.isRendering = true
        try {
            nAngleMakeCurrent(device)
            update()
            skiaLayer.inDrawScope {
                contextHandler.draw()
            }
            nAngleSwapBuffers(device, 0)
        } finally {
            skiaLayer.isRendering = false
            isRendering = false
        }
    }

    override val renderInfo: String
        get() = contextHandler.rendererInfo()

    override fun isTransparentBackgroundSupported(): Boolean =
        defaultIsTransparentBackgroundSupported(skiaLayer)
}

@ExternalSymbolName("angle_create_device")
private external fun nAngleCreateDevice(hwndPtr: Long): NativePointer

@ExternalSymbolName("angle_make_current")
private external fun nAngleMakeCurrent(devicePtr: NativePointer)

@ExternalSymbolName("angle_swap_buffers")
private external fun nAngleSwapBuffers(devicePtr: NativePointer, vsync: Int)

@ExternalSymbolName("angle_dispose")
private external fun nAngleDispose(devicePtr: NativePointer)
