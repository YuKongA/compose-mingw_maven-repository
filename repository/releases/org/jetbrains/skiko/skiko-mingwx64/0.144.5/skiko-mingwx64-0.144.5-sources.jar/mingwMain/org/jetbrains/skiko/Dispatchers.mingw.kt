package org.jetbrains.skiko

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

object SkikoDispatchers {
    // Use Unconfined so that FrameDispatcher.draw() runs on the thread that called
    // needRender() (the Win32 message loop thread), avoiding multithreaded access
    // to Compose's SnapshotStateObserver.
    val Main: CoroutineDispatcher = Dispatchers.Unconfined
}
