/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:OptIn(ExperimentalForeignApi::class)

package androidx.compose.ui.window

import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import platform.windows.DispatchMessageW
import platform.windows.GetMessageW
import platform.windows.MSG
import platform.windows.PostQuitMessage
import platform.windows.TranslateMessage

interface ApplicationScope {
    fun exitApplication()
}

/**
 * Entry point for a Compose Desktop application on mingwX64.
 *
 * Usage:
 * ```kotlin
 * fun main() = application {
 *     Window(title = "My App") {
 *         Text("Hello!")
 *     }
 * }
 * ```
 *
 * The [content] block is called synchronously to create windows via [Window].
 * After that, a Win32 message loop runs until all windows are closed or
 * [ApplicationScope.exitApplication] is called.
 */
fun application(content: ApplicationScope.() -> Unit) {
    ensureWindowClassRegistered()

    val scope = object : ApplicationScope {
        override fun exitApplication() {
            PostQuitMessage(0)
        }
    }

    // Execute content to create windows
    scope.content()

    // Win32 message loop
    memScoped {
        val msg = alloc<MSG>()
        while (GetMessageW(msg.ptr, null, 0u, 0u) > 0) {
            TranslateMessage(msg.ptr)
            DispatchMessageW(msg.ptr)
        }
    }
}
