/*
 * Copyright 2025 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

@file:OptIn(ExperimentalForeignApi::class)

package androidx.compose.ui.window

import androidx.compose.runtime.Composable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asComposeCanvas
import androidx.compose.ui.input.key.createComposeKeyEvent
import androidx.compose.ui.input.pointer.MingwCursor
import androidx.compose.ui.input.pointer.PointerButton
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.PointerIcon
import androidx.compose.ui.platform.DefaultArchitectureComponentsOwner
import androidx.compose.ui.platform.MingwTextInputService
import androidx.compose.ui.platform.PlatformContext
import androidx.compose.ui.platform.WindowInfoImpl
import androidx.compose.ui.scene.CanvasLayersComposeScene
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toDpSize
import androidx.compose.ui.unit.toSize
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.enableSavedStateHandles
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.alloc
import kotlinx.cinterop.memScoped
import kotlinx.cinterop.ptr
import kotlinx.cinterop.reinterpret
import kotlinx.cinterop.sizeOf
import kotlinx.cinterop.staticCFunction
import kotlinx.cinterop.toCPointer
import kotlinx.cinterop.toLong
import kotlinx.cinterop.wcstr
import kotlinx.coroutines.Dispatchers
import org.jetbrains.skia.Canvas
import org.jetbrains.skiko.SkiaLayer
import org.jetbrains.skiko.SkikoRenderDelegate
import platform.windows.CW_USEDEFAULT
import platform.windows.CS_HREDRAW
import platform.windows.CS_VREDRAW
import platform.windows.CreateWindowExW
import platform.windows.DefWindowProcW
import platform.windows.GetModuleHandleW
import platform.windows.HTCLIENT
import platform.windows.HWND
import platform.windows.IDC_ARROW
import platform.windows.LPARAM
import platform.windows.LRESULT
import platform.windows.LoadCursorW
import platform.windows.PostQuitMessage
import platform.windows.RegisterClassExW
import platform.windows.SW_SHOW
import platform.windows.SetCursor
import platform.windows.ShowWindow
import platform.windows.GetStockObject
import platform.windows.UINT
import platform.windows.UpdateWindow
import platform.windows.WHITE_BRUSH
import platform.windows.WM_DESTROY
import platform.windows.WM_KEYDOWN
import platform.windows.WM_KEYUP
import platform.windows.WM_KILLFOCUS
import platform.windows.WM_LBUTTONDOWN
import platform.windows.WM_LBUTTONUP
import platform.windows.WM_MBUTTONDOWN
import platform.windows.WM_MBUTTONUP
import platform.windows.WM_MOUSEMOVE
import platform.windows.WM_MOUSEWHEEL
import platform.windows.WM_PAINT
import platform.windows.WM_RBUTTONDOWN
import platform.windows.WM_RBUTTONUP
import platform.windows.WM_SETFOCUS
import platform.windows.WM_SIZE
import platform.windows.WM_SYSKEYDOWN
import platform.windows.WM_SYSKEYUP
import platform.windows.WNDCLASSEXW
import platform.windows.WPARAM
import platform.windows.WS_OVERLAPPEDWINDOW
import platform.windows.WHEEL_DELTA
import platform.windows.WM_MOUSEHWHEEL
import platform.windows.WM_SETCURSOR

private const val COMPOSE_WINDOW_CLASS = "ComposeWindowClass"
private var windowClassRegistered = false

// Global map from HWND to ComposeWindow for WndProc dispatch
private val windowMap = mutableMapOf<Long, ComposeWindow>()

interface WindowScope {
    val hwnd: HWND
}

fun Window(
    title: String = "ComposeWindow",
    size: DpSize = DpSize(800.dp, 600.dp),
    content: @Composable WindowScope.() -> Unit,
) {
    ComposeWindow(
        title = title,
        size = size,
        content = content,
    )
}

internal fun ensureWindowClassRegistered() {
    if (windowClassRegistered) return
    memScoped {
        val hInstance = GetModuleHandleW(null)
        val wc = alloc<WNDCLASSEXW>()
        wc.cbSize = sizeOf<WNDCLASSEXW>().toUInt()
        wc.style = (CS_HREDRAW or CS_VREDRAW).toUInt()
        wc.lpfnWndProc = staticCFunction(::composeWndProc)
        wc.hInstance = hInstance
        wc.hCursor = LoadCursorW(null, IDC_ARROW)
        wc.hbrBackground = GetStockObject(WHITE_BRUSH)?.reinterpret()
        wc.lpszClassName = COMPOSE_WINDOW_CLASS.wcstr.ptr
        RegisterClassExW(wc.ptr)
    }
    windowClassRegistered = true
}

private fun composeWndProc(hwnd: HWND?, msg: UINT, wParam: WPARAM, lParam: LPARAM): LRESULT {
    val window = hwnd?.let { windowMap[it.toLong()] }
    if (window != null) {
        val result = window.handleMessage(msg, wParam, lParam)
        if (result != null) return result
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam)
}

internal class ComposeWindow(
    title: String,
    size: DpSize,
    content: @Composable WindowScope.() -> Unit,
) : WindowScope {
    private var isDisposed = false
    private val mingwTextInputService = MingwTextInputService()
    private val _windowInfo = WindowInfoImpl().apply {
        isWindowFocused = true
    }
    private val archComponentsOwner = DefaultArchitectureComponentsOwner(
        enforceMainThread = false
    )
    private val platformContext: PlatformContext =
        object : PlatformContext by PlatformContext.Empty() {
            override val windowInfo get() = _windowInfo
            override val architectureComponentsOwner get() = archComponentsOwner
            override val textInputService get() = mingwTextInputService
            override fun setPointerIcon(pointerIcon: PointerIcon) {
                val cursor = (pointerIcon as? MingwCursor)?.let {
                    LoadCursorW(null, it.cursorId.toLong().toCPointer())
                } ?: LoadCursorW(null, IDC_ARROW)
                SetCursor(cursor)
            }
        }
    private val skiaLayer = SkiaLayer()
    private val scene = CanvasLayersComposeScene(
        coroutineContext = Dispatchers.Unconfined,
        platformContext = platformContext,
        invalidate = skiaLayer::needRender,
    )
    private val renderDelegate = object : SkikoRenderDelegate {
        override fun onRender(canvas: Canvas, width: Int, height: Int, nanoTime: Long) {
            val sizeInPx = IntSize(width, height)
            _windowInfo.containerSize = sizeInPx
            _windowInfo.containerDpSize = sizeInPx.toSize().toDpSize(scene.density)
            scene.size = sizeInPx
            scene.render(canvas.asComposeCanvas(), nanoTime)
        }
    }

    override val hwnd: HWND

    init {
        ensureWindowClassRegistered()

        val hInstance = GetModuleHandleW(null)
        hwnd = CreateWindowExW(
            0u,
            COMPOSE_WINDOW_CLASS,
            title,
            WS_OVERLAPPEDWINDOW.toUInt(),
            CW_USEDEFAULT, CW_USEDEFAULT,
            size.width.value.toInt(), size.height.value.toInt(),
            null, null, hInstance, null
        ) ?: error("CreateWindowExW failed")

        windowMap[hwnd.toLong()] = this

        skiaLayer.renderDelegate = renderDelegate
        skiaLayer.attachTo(hwnd)

        ShowWindow(hwnd, SW_SHOW)
        UpdateWindow(hwnd)

        scene.density = Density(skiaLayer.contentScale)
        scene.setContent {
            content()
        }

        archComponentsOwner.enableSavedStateHandles()
        archComponentsOwner.lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }

    fun dispose() {
        if (isDisposed) return
        isDisposed = true
        archComponentsOwner.lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        archComponentsOwner.viewModelStore.clear()
        skiaLayer.detach()
        scene.close()
        windowMap.remove(hwnd.toLong())
    }

    internal fun handleMessage(msg: UINT, wParam: WPARAM, lParam: LPARAM): LRESULT? {
        if (isDisposed) return null
        return when (msg.toInt()) {
            WM_DESTROY -> {
                dispose()
                PostQuitMessage(0)
                0
            }
            WM_SIZE -> {
                skiaLayer.needRender()
                0
            }
            WM_PAINT -> {
                skiaLayer.needRender()
                null // Let DefWindowProc validate the region
            }
            WM_SETFOCUS -> {
                _windowInfo.isWindowFocused = true
                0
            }
            WM_KILLFOCUS -> {
                _windowInfo.isWindowFocused = false
                0
            }
            WM_MOUSEMOVE -> {
                onMouseEvent(PointerEventType.Move, lParam)
                0
            }
            WM_LBUTTONDOWN -> {
                onMouseEvent(PointerEventType.Press, lParam, PointerButton.Primary)
                0
            }
            WM_LBUTTONUP -> {
                onMouseEvent(PointerEventType.Release, lParam, PointerButton.Primary)
                0
            }
            WM_RBUTTONDOWN -> {
                onMouseEvent(PointerEventType.Press, lParam, PointerButton.Secondary)
                0
            }
            WM_RBUTTONUP -> {
                onMouseEvent(PointerEventType.Release, lParam, PointerButton.Secondary)
                0
            }
            WM_MBUTTONDOWN -> {
                onMouseEvent(PointerEventType.Press, lParam, PointerButton.Tertiary)
                0
            }
            WM_MBUTTONUP -> {
                onMouseEvent(PointerEventType.Release, lParam, PointerButton.Tertiary)
                0
            }
            WM_MOUSEWHEEL -> {
                val delta = (wParam.toInt() shr 16).toShort().toFloat() / WHEEL_DELTA
                scene.sendPointerEvent(
                    eventType = PointerEventType.Scroll,
                    position = lParamToOffset(lParam),
                    scrollDelta = Offset(0f, -delta),
                    nativeEvent = null,
                )
                0
            }
            WM_MOUSEHWHEEL -> {
                val delta = (wParam.toInt() shr 16).toShort().toFloat() / WHEEL_DELTA
                scene.sendPointerEvent(
                    eventType = PointerEventType.Scroll,
                    position = lParamToOffset(lParam),
                    scrollDelta = Offset(delta, 0f),
                    nativeEvent = null,
                )
                0
            }
            WM_KEYDOWN, WM_SYSKEYDOWN -> {
                val event = createComposeKeyEvent(msg, wParam)
                scene.sendKeyEvent(event)
                0
            }
            WM_KEYUP, WM_SYSKEYUP -> {
                val event = createComposeKeyEvent(msg, wParam)
                scene.sendKeyEvent(event)
                0
            }
            WM_SETCURSOR -> {
                if ((lParam.toInt() and 0xFFFF) == HTCLIENT) {
                    // Let Compose handle cursor in client area
                    1
                } else {
                    null
                }
            }
            else -> null
        }
    }

    private fun onMouseEvent(
        eventType: PointerEventType,
        lParam: LPARAM,
        button: PointerButton? = null,
    ) {
        if (isDisposed) return
        scene.sendPointerEvent(
            eventType = eventType,
            position = lParamToOffset(lParam),
            nativeEvent = null,
            button = button,
        )
    }

    private fun lParamToOffset(lParam: LPARAM): Offset {
        val x = (lParam.toInt() and 0xFFFF).toShort().toFloat()
        val y = ((lParam.toInt() shr 16) and 0xFFFF).toShort().toFloat()
        return Offset(x, y)
    }
}
