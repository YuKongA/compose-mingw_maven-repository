package org.jetbrains.skiko

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

object SkikoDispatchers {
    val Main: CoroutineDispatcher = Dispatchers.Default
}
