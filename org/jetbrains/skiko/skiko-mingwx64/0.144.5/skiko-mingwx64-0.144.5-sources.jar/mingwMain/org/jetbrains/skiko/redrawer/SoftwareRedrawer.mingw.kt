package org.jetbrains.skiko.redrawer

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import org.jetbrains.skiko.FrameDispatcher
import org.jetbrains.skiko.SkiaLayer
import org.jetbrains.skiko.SkikoDispatchers
import org.jetbrains.skiko.context.MingwSoftwareContextHandler

internal class MingwSoftwareRedrawer(
    private val skiaLayer: SkiaLayer
) : Redrawer {

    private val contextHandler = MingwSoftwareContextHandler(skiaLayer)
    private val coroutineScope = CoroutineScope(SkikoDispatchers.Main + Job())
    private val frameDispatcher = FrameDispatcher(coroutineScope) { draw() }
    private var isDisposed = false

    override fun dispose() {
        if (isDisposed) return
        isDisposed = true
        frameDispatcher.cancel()
        contextHandler.dispose()
    }

    override fun needRender(throttledToVsync: Boolean) {
        check(!isDisposed) { "MingwSoftwareRedrawer is disposed" }
        frameDispatcher.scheduleFrame()
    }

    override fun update(nanoTime: Long) {
        check(!isDisposed) { "MingwSoftwareRedrawer is disposed" }
        skiaLayer.update(nanoTime)
    }

    override fun renderImmediately() {
        check(!isDisposed) { "MingwSoftwareRedrawer is disposed" }
        if (!isDisposed) {
            update()
        }
        if (!isDisposed) {
            skiaLayer.inDrawScope {
                contextHandler.draw()
            }
        }
    }

    private fun draw() {
        if (isDisposed) return
        update()
        skiaLayer.inDrawScope {
            contextHandler.draw()
        }
    }

    override val renderInfo: String
        get() = contextHandler.rendererInfo()

    override fun isTransparentBackgroundSupported(): Boolean =
        defaultIsTransparentBackgroundSupported(skiaLayer)
}
