package org.jetbrains.skiko

import org.jetbrains.skiko.redrawer.MingwSoftwareRedrawer
import org.jetbrains.skiko.redrawer.Redrawer

internal fun createNativeRedrawer(
    layer: SkiaLayer,
    renderApi: GraphicsApi
): Redrawer = when (renderApi) {
    GraphicsApi.SOFTWARE_FAST -> MingwSoftwareRedrawer(layer)
    else -> throw IllegalArgumentException("Unsupported API $renderApi for mingwX64")
}
